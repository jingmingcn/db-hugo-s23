
The python3 is required to run this demo.

```python
python3 main.py
```