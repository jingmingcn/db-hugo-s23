
DB_FILE = 'stu.db'
INDEX_FILE = 'stu.idx'

class student:

    def __init__(self, *args, **kwargs):
        #args -- tuple of anonymous arguments
        #kwargs -- dictionary of named arguments
        if len(args) == 0:
            self.num = kwargs['num']
            self.name = kwargs['name']
            self.college = kwargs['college']
            self.phone = kwargs['phone']
        else:
            s = args[0].split(',')
            self.num = s[0].strip()
            self.name = s[1].strip()
            self.college = s[2].strip()
            self.phone = s[3].strip()

    def __str__(self):
        return '{0: <24},{1: <24},{2: <24},{3: <25}'.format(self.num, self.name, self.college, self.phone)

class stu_db_file:
    
    def __init__(self):
        self.index = {}
        self.read_index()

        
    def insert(self, stu):

        if stu.num in self.index:
            return

        offset = 0
        if len(self.index) != 0:
            offset = max(self.index.values()) + 100

        self.write_stu(stu,offset)
        self.index[stu.num] = offset
        self.write_index()


    def delete(self, num):
        if num not in self.index:
            return
        
        offset = self.index[num]
        db_file = open(DB_FILE,'rb+')
        db_file.seek(offset)
        db_file.write('{: >100}'.format(' ').encode())
        db_file.close()

        self.index.pop(num)
        self.write_index()
        


    def update(self, oldnum, stu):
        if oldnum not in self.index:
            return
        
        offset = self.index[oldnum]
        self.write_stu(stu,offset)

        self.index.pop(oldnum)
        self.index[stu.num] = int(offset)
        self.write_index()
    
    def select_by_num(self, num):
        if num not in self.index:
            return

        offset = self.index[num]

        db_file = open(DB_FILE,'r')
        db_file.seek(offset)
        s = db_file.read(100)
        db_file.close()

        return student(str(s))

    def select_by_name(self, name):
        ''' Give your code here to implement the search by name with and without index  '''
        
    def read_index(self):

        index_file = open(INDEX_FILE,'r')
        lines = index_file.readlines()

        for line in lines:
            s = line.split(',')
            self.index[s[0]] = int(s[1])

        index_file.close()

    def write_index(self):

        index_file = open(INDEX_FILE,'w')

        for k, v in self.index.items():
            index_file.write('{},{}\n'.format(k,v))

        index_file.close()

    def write_stu(self, stu, offset):
        db_file = open(DB_FILE,'rb+')
        db_file.seek(offset)
        db_file.write(str(stu).encode())
        db_file.close()
        


def main():

    '''Give your code here to test the actions (select, insert, update, delete).'''

    stu = student(num='009',name='Ming',college='CS',phone='13100000000')

    db = stu_db_file()
    db.insert(stu)
    
    # stu.num = '100'
    # db.update('004',stu)
    # db.delete('100')

    print(db.select_by_num('004'))


if __name__ == "__main__":
    main()